# from app.retriever.retriever import retrieve
# from app.llm.groq_client import generate_answer
# from app.tools.web_search import web_search
# from app.agent.prompt import tool_decision_prompt
# from app.utils.logger import logger
# from app.config.settings import settings



# def decide_tool(query):
#     prompt = tool_decision_prompt(query)
#     decision = generate_answer(prompt)
#     return decision.strip().lower()


# def rag_agent(query: str):

#     context, score = retrieve(query)

#     logger.info(f"Similarity score: {score}")

#     if score >= settings.SIMILARITY_THRESHOLD:
#         logger.info("Using vector database")
#         context_text = "\n".join(context)

#     else:
#         logger.info("Low score → using web search")
#         context_text = web_search(query)

#     final_prompt = f"""
#     You are a friendly AI assistant.

#     Answer in a natural conversational tone.
#     Do not use markdown formatting.
#     Do not use bullet points.
#     Explain clearly in simple language.

#     If context is provided, use it naturally.

#     Context:
#     {context_text}

#     Question:
#     {query}
#     """

#     return generate_answer(final_prompt)


import json
from app.retriever.retriever import retrieve
from app.llm.groq_client import generate_answer
from app.tools.web_search import web_search
from app.agent.prompt import tool_decision_prompt
from app.utils.logger import logger


def rag_agent(query: str):

    # 1️⃣ Ask LLM which tool to use
    decision_prompt = tool_decision_prompt(query)
    decision_raw = generate_answer(decision_prompt)

    logger.info(f"Raw tool decision: {decision_raw}")

    try:
        decision = json.loads(decision_raw)
        tool = decision.get("tool")
        args = decision.get("arguments", {})
    except Exception:
        logger.warning("Invalid JSON from model, defaulting to direct_answer")
        tool = "direct_answer"
        args = {}

    # 2️⃣ Execute selected tool
    if tool == "vector_search":
        logger.info("Executing vector_search")
        context, score = retrieve(args.get("query", query))
        context_text = "\n".join(context)

    elif tool == "web_search":
        logger.info("Executing web_search")
        context_text = web_search(args.get("query", query))

    else:
        logger.info("Using direct_answer")
        context_text = ""

    # 3️⃣ Final answer generation
    final_prompt = f"""
You are a friendly AI assistant.

Use the tool results below if provided.

Context:
{context_text}

Question:
{query}

Answer naturally and clearly.
Avoid markdown formatting.
"""

    return generate_answer(final_prompt)