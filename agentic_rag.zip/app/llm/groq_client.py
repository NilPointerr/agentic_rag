from groq import Groq
from app.config.settings import settings

client = Groq(api_key=settings.GROQ_API_KEY)

def generate_answer(prompt: str):
    response = client.chat.completions.create(
        # model="mixtral-8x7b-32768",
        model = "openai/gpt-oss-20b",
        messages=[
            {"role": "system", "content": "You are a helpful AI assistant."},
            {"role": "user", "content": prompt}
        ],
        temperature=0.2
    )
    return response.choices[0].message.content